package com.example.android_qrreader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {

    TextView res;
    IntentIntegrator intentIntegrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        res = (TextView)findViewById(R.id.result);

        intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.setOrientationLocked(false); // 핸드폰 가로-세로 모드에 따라 방향 변경
        intentIntegrator.setPrompt("QR코드 스캔 화면\n \n \n ");
    }

    public void onClick(View v){
        intentIntegrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == IntentIntegrator.REQUEST_CODE){
            IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if(result.getContents() == null) {
                // 스캔 실패 or Null
                Toast.makeText(this, "Cancelled or Null", Toast.LENGTH_LONG).show();
                res.setText(result.toString()+"\nrequestCode: "+requestCode+"\nresultCode: "+resultCode+"\nData: "+data);
            } else {
                // 스캔 성공
                Toast.makeText(this, "Scanned", Toast.LENGTH_LONG).show();
                res.setText(result.getContents());
            }
                //res.setText(result.toString());
        }
    }
}